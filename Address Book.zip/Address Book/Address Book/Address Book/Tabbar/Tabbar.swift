//**********************************************************************************************
//
//  Tabbar.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI

struct Tabbar: View {
    var body: some View {
        
        ZStack{
            //tab bar
            
            TabView {
                
                FavouritesView() //Favourites tab
                
                    .tabItem {
                        Image(systemName: "star.circle.fill")
                        Text("Favourites")
                    }
                
                ContactsListView() //Contact tab
                
                    .tabItem {
                        Image(systemName: "person.circle")
                        Text("Contacts")
                        
                    }
                
                GroupListView() //Group tab
                
                    .tabItem {
                        Image(systemName: "person.3.fill")
                        Text("Groups")
                    }
               
                DuplicatesListView() //Duplicate tab
                
                    .tabItem {
                        Image(systemName: "person.2.circle")
                        Text("Duplicates")
                    }
            }
            .accentColor(Color.AppTheme.appPrimary)
        }
        .padding(.top,5)
    }
}

struct Tabbar_Previews: PreviewProvider {
    static var previews: some View {
        Tabbar()
    }
}
