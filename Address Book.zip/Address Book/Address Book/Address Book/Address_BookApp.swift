//**********************************************************************************************
//
//  Address_BookApp.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI
@main
struct Address_BookApp: App {
    
    // Create an instance of PersistenceController for managing Core Data
    let persistenceController = PersistenceController.shared
    
    // Initialize the app's appearance settings
    init() {
        // Customize navigation bar appearance
        let navigationbarAppearance = UINavigationBarAppearance()
        navigationbarAppearance.backgroundColor = .white
        navigationbarAppearance.titleTextAttributes = [.foregroundColor : UIColor.black, .font : UIFont.systemFont(ofSize: 20, weight: .semibold)]
        
        // Apply the customized appearance to different navigation bar states
        UINavigationBar.appearance().standardAppearance = navigationbarAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navigationbarAppearance
        UINavigationBar.appearance().compactAppearance = navigationbarAppearance
        UINavigationBar.appearance().compactScrollEdgeAppearance = navigationbarAppearance
        
        // Customize tab bar appearance
        let tabbarAppeance = UITabBarAppearance()
        tabbarAppeance.backgroundColor = UIColor.AppTheme.appPrimary
        tabbarAppeance.stackedLayoutAppearance.normal.iconColor = .white.withAlphaComponent(0.7)
        tabbarAppeance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor : UIColor.white.withAlphaComponent(0.7)]
        
        tabbarAppeance.stackedLayoutAppearance.selected.iconColor = UIColor.white
        tabbarAppeance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor : UIColor.white]
        
        // Apply the customized appearance to different tab bar states
        UITabBar.appearance().standardAppearance = tabbarAppeance
        UITabBar.appearance().scrollEdgeAppearance = tabbarAppeance
    }
    
    ///Define the main scene of the application
    var body: some Scene {
        // Create a window group for managing the app's main UI
        WindowGroup {
            // Load the Tabbar view as the initial screen and provide the managed object context
            Tabbar().environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}

