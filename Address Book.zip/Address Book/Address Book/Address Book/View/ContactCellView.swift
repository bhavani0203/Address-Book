//**********************************************************************************************
//
//  ContactCellView.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI

/**
 View for displaying a contact cell.
 */
struct ContactCellView: View {
    
    // MARK: - Properties
    
    var contact: ContactInfo
    @StateObject var favViewModel: FavouritesViewModel
    
    // MARK: - Body
    
    var body: some View {
        
        HStack {
            
            // Contact image
            if let imageData = contact.contact.imageData {
                Image(uiImage: UIImage(data: imageData)!)
                    .resizable()
                    .frame(width: 45, height: 45)
                    .contentShape(Capsule())
            } else {
                Image("ic_placeholder")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .contentShape(Capsule())
            }
            
            // Contact name
            Text("\(contact.firstName) \(contact.lastName)")
                .font(.system(size: 17, weight: .medium))
                .foregroundColor(.primary)
            
            Spacer()
            
            HStack(spacing: 15) {
                
                // Phone call button
                if contact.phoneNumber != nil {
                    Button {
                        dialNumber(number: contact.phoneNumber!.stringValue)
                    } label: {
                        Image(systemName: "phone.fill").foregroundColor(Color.green)
                    }
                    .buttonStyle(.plain)
                }
                
                // Favorites tab
                Button {
                    favViewModel.setFavUnfav(contactID: contact.contact.identifier)
                } label: {
                    Image(systemName: favViewModel.isFav(contactId: contact.contact.identifier) ? "star.fill" : "star")
                        .foregroundColor(Color.green)
                }
                .buttonStyle(.plain)
            }
        }
    }
    
    // MARK: - Helper Functions
    
    /**
     Initiates a phone call to the specified number.
     
     - Parameter number: The phone number to dial.
     */
    func dialNumber(number: String) {
        if let url = URL(string: "tel://\(number)"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        } else {
            // Handle error or show alert
        }
    }
}

