//**********************************************************************************************
//
//  GroupContactList.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI
import Contacts
import ContactsUI
import CoreData

/**
 View for displaying contacts in a group.
 */
struct GroupContactList: View {
    
    @State private var contacts = [ContactInfo]()
    @State private var searchText = ""
    @State private var showCancelButton: Bool = false
    @State var isShow = false
    @State var selectedContact = CNContact()
    @State var group: Group
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Contacts.contactId, ascending: true)],
        animation: .default)
    
    private var items: FetchedResults<Contacts>
    
    @State private var multiSelection = Set<String>()
    @StateObject var favViewModel = FavouritesViewModel()
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                
                //MARK: - Search Bar
                
                HStack {
                    
                    HStack {
                        
                        // Search bar magnifying glass image
                        Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                        
                        // Search bar text field
                        TextField("Search", text: self.$searchText, onEditingChanged: { isEditing in
                            
                            self.showCancelButton = true
                        })
                        
                        // X Button
                        Button(action: {
                            
                            self.searchText = ""
                            
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                                .opacity(self.searchText == "" ? 0 : 1)
                        }
                    }
                    .padding(8)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(8)
                    
                    // Cancel Button
                    if self.showCancelButton {
                        
                        Button("Cancel") {
                            UIApplication.shared.endEditing(true)
                            self.searchText = ""
                            self.showCancelButton = false
                        }
                    }
                }
                .padding([.leading, .trailing])
                .padding(.top, 10)
                
                //MARK: - Contact List
                
                List {
                    
                    ForEach(searchText.isEmpty ? contacts : filteredContact(searchText)) { contact in
                        
                        ContactCellView(contact: contact, favViewModel: favViewModel)
                            .onTapGesture {
                                
                                selectedContact = contact.contact
                                isShow = true
                            }
                    }
                    .onDelete(perform: deleteItems) // Swipe to remove contact from group
                }
                .listStyle(.insetGrouped)
                .toolbar {
                    
                    //MARK: - Add Button
                    
                    ToolbarItem {
                        
                        NavigationLink {
                            
                            ContactList(group: group)
                                .navigationTitle("Contact list")
                            
                        } label: {
                            
                            Label("Add Contact", systemImage: "plus")
                        }
                    }
                }
            }
            .fullScreenCover(isPresented: $isShow, content: {
                
                addContact()
                    .onDisappear(perform: {
                        
                        favViewModel.getFav()
                        self.requestAccess()
                    })
                    .tint(Color.AppTheme.appPrimary)
                    .navigationBarHidden(true)
                    .navigationBarBackButtonHidden(true)
            })
            .onAppear() {
                
                favViewModel.getFav()
                self.requestAccess() // Ask for permission and fetch contacts
            }
        }
    }
    
    /**
     Fetches contacts from the device.
     */
    func getContacts() {
        
        print("group.contact_list count::", group.contact_list?.allObjects.count ?? 0)
        
        DispatchQueue.global(qos: .background).async {
          
            let allContact = FetchContacts().fetchingContacts(isGroup: false, Group: [Contacts](), isUnselecte: false)
            let contact = group.contact_list?.allObjects as! [Contacts]
            
            if contact.isEmpty {
                
                contacts.removeAll()
            }
            else
            {
                var arrNewContacts = [ContactInfo]()
                for data in allContact {
                    
                    if contact.first(where: {$0.contactId == data.contact.identifier}) != nil {
                        
                        arrNewContacts.append(data)
                        multiSelection.insert(data.contact.identifier)
                    }
                    
                    if data == allContact.last {
                        
                        contacts = arrNewContacts
                    }
                }
            }
        }
    }
    
    /**
     Requests access to contacts.
     */
    func requestAccess() {
        
        switch CNContactStore.authorizationStatus(for: .contacts) {
        case .authorized:
            self.getContacts()
        case .denied:
            store.requestAccess(for: .contacts) { granted, error in
                if granted {
                    self.getContacts()
                }
            }
        case .restricted, .notDetermined:
            store.requestAccess(for: .contacts) { granted, error in
                if granted {
                    self.getContacts()
                }
            }
        @unknown default:
            print("error")
        }
    }
    
    /**
     Creates a MyCNContactViewController for showing contact details.
     
     - Returns: MyCNContactViewController instance.
     */
    func addContact() -> MyCNContactViewController {
        
        let vc = MyCNContactViewController(contact: $selectedContact)
        return vc
    }
    
    /**
     Deletes selected items from the group's contacts.
     
     - Parameter offsets: Index set of items to delete.
     */
    private func deleteItems(offsets: IndexSet) {
        
        let index = offsets[offsets.startIndex]
        let contact = contacts[index]
        
        let fetchReq: NSFetchRequest<Contacts>
        fetchReq = Contacts.fetchRequest()
        
        let contactPredict = NSPredicate(format: "contactId == %@", contact.contact.identifier)
        let groupIdPredict = NSPredicate(format: "groupId == %@", group.groupID!)
        let andPredicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: [contactPredict, groupIdPredict])
        fetchReq.predicate =  andPredicate
        let getData = try? self.viewContext.fetch(fetchReq)
        
        if getData?.count != 0 {
            
            let contactData = getData![0]
            
            group.removeFromContact_list(contactData)
            viewContext.delete(contactData)
            contacts.remove(atOffsets: offsets)
            
            if let pos = multiSelection.firstIndex(where: {$0 == contact.contact.identifier}) {
                
                multiSelection.remove(at: pos)
            }
            do {
                
                try self.viewContext.save()
                print("Contact removed from group")
            }
            catch
            {
                print("Delete group contact error:", error.localizedDescription)
            }
            
        }
    }
    
    /**
     Filters contacts based on the search query.
     
     - Parameter query: Search query string.
     - Returns: Filtered array of ContactInfo.
     */
    func filteredContact(_ query: String) -> [ContactInfo] {
        
        let lowercasedQuery = query.lowercased()
        return contacts.filter { $0.firstName.lowercased().contains(lowercasedQuery) || $0.lastName.lowercased().contains(lowercasedQuery)}
    }
    
}

struct GroupContactList_Previews: PreviewProvider {
    static var previews: some View {
        GroupContactList(group: Group())
    }
}

