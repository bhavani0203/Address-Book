//**********************************************************************************************
//
//  ContactList.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI
import CoreData
import Contacts
import ContactsUI

/**
 View for selecting contacts to add to a group.
 */
struct ContactList: View {
    
    @State private var contacts = [ContactInfo.init(id: "", firstName: "", lastName: "", phoneNumber: nil)]
    @State private var searchText = ""
    @State private var showCancelButton: Bool = false
    @State var isList: Bool = true
  
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Contacts.contactId, ascending: true)],
        animation: .default)
    private var items: FetchedResults<Contacts>
    
    @State var group: Group
    @State var multiSelection = Set<String>()
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                
                //MARK: - Search Bar
                
                HStack {
                    
                    HStack {
                        
                        // Search bar magnifying glass image
                        Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                        
                        // Search bar text field
                        TextField("Search", text: self.$searchText, onEditingChanged: { isEditing in
                            self.showCancelButton = true
                        })
                        
                        // X Button
                        Button(action: {
                            self.searchText = ""
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                                .opacity(self.searchText == "" ? 0 : 1)
                        }
                    }
                    .padding(8)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(8)
                    
                    // Cancel Button
                    if self.showCancelButton {
                        Button("Cancel") {
                            UIApplication.shared.endEditing(true)
                            self.searchText = ""
                            self.showCancelButton = false
                        }
                    }
                }
                .padding([.leading, .trailing, .top])
                
                //MARK: - Group Contact List
                
                List {
                    
                    ForEach(searchText.isEmpty ? contacts : filteredContact(searchText)) { contact in
                        
                        HStack{
                            
                            Button {
                                
                                if let pos = multiSelection.firstIndex(where: {$0 == contact.contact.identifier}) {
                                    
                                    multiSelection.remove(at: pos)
                                }
                                else
                                {
                                    multiSelection.insert(contact.contact.identifier)
                                }
                                
                            } label: {
                                
                                Image(multiSelection.contains(contact.contact.identifier) ? "ic_fill" : "ic_unfill")
                                    .resizable()
                                    .frame(width: 22, height: 22, alignment: .leading)
                                
                                Text("\(contact.firstName) \(contact.lastName)").foregroundColor(.primary)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .toolbar {
                    
                    ToolbarItem(placement: .topBarTrailing) {
                        
                        //MARK: - Done Button
                        
                        Button { // Add selected contact in group and store into coredata
                            
                            let fetchReq :NSFetchRequest<Group>
                            fetchReq = Group.fetchRequest()
                            fetchReq.predicate =  NSPredicate(format: "groupID == %@", group.groupID!)
                            let getData = try? self.viewContext.fetch(fetchReq)
                            
                            if getData?.count != 0 {
                                
                                let groupData = getData![0]
                                
                                for data in multiSelection {
                                    
                                    let new = Contacts(context: viewContext)
                                    new.contactId = "\(data)"
                                    new.groupId = group.groupID
                                    new.group = groupData
                                    groupData.contact_list?.addingObjects(from: [new])
                                }
                                
                                do {
                                    
                                    try self.viewContext.save()
                                    dismiss()
                                }
                                catch
                                {
                                    
                                }
                            }
                            else
                            {
                                dismiss()
                            }
                          
                        } label: {
                            
                            Text("Done")
                        }
                    }
                }
                .onAppear() {
                    // On appear fetch contact list
                    self.getContacts()
                    
                }
            }
        }
    }
    
    /**
     Fetches contacts from the device.
     */
    func getContacts() {
        
        DispatchQueue.global(qos: .background).async {
            
            self.contacts = FetchContacts().fetchingContacts(isGroup: true, Group: group.contact_list?.allObjects as! [Contacts], isUnselecte: true)
        }
    }
    
    /**
     Filters contacts based on the search query.
     
     - Parameter query: Search query string.
     - Returns: Filtered array of ContactInfo.
     */
    func filteredContact(_ query: String) -> [ContactInfo] {
        
        let lowercasedQuery = query.lowercased()
        return contacts.filter { $0.firstName.lowercased().contains(lowercasedQuery) || $0.lastName.lowercased().contains(lowercasedQuery)}
    }
}

struct ContactList_Previews: PreviewProvider {
    
    static var previews: some View {
        ContactList(group: Group())
    }
}

