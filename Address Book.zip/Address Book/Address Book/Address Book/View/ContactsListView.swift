//**********************************************************************************************
//
//  FetchContacts.swift
//  ContactsListView Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI
import CoreData
import Contacts
import ContactsUI

/**
 Enum to manage active alerts in the ContactsListView.
 */
enum ActiveAlert {
    
    case delete, contact_accesss
}

/**
 View for displaying and managing contacts.
 */
struct ContactsListView: View {
    
    // MARK: - State Variables
    
    @State private var searchText = ""
    @State private var showCancelButton: Bool = false
    @State var isLogin = false
    @State var selectedContact = CNContact()
    @State var deletedContact = CNContact()
    
    @StateObject var favoritesViewModel = FavouritesViewModel()
    @StateObject var contactViewModel = ContactViewModel(pageType: .contact)

    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            VStack {
                
                // MARK: - Search Bar
                
                HStack {
                    // Search bar components
                    HStack {
                        // Search bar magnifying glass image
                        Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                        
                        // Search bar text field
                        TextField("search", text: self.$searchText, onEditingChanged: { isEditing in
                            
                            self.showCancelButton = true
                        })
                        
                        // X Button
                        Button(action: {
                            
                            self.searchText = ""
                        })
                        {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                                .opacity(self.searchText == "" ? 0 : 1)
                        }
                    }
                    .padding(8)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(8)
                    
                    // Cancel Button
                    if self.showCancelButton  {
                        
                        Button("Cancel") {
                            
                            UIApplication.shared.endEditing(true)
                            self.searchText = ""
                            self.showCancelButton = false
                        }
                    }
                }
                .padding([.leading, .trailing])
                .padding(.top,10)
               
                // MARK: - Contact List
                
                List {
                    ForEach (searchText.isEmpty ? contactViewModel.contacts : contactViewModel.filteredContact(searchText)) { contact in
                        // Contact list row view
                        ContactCellView(contact: contact, favViewModel: favoritesViewModel) // Contact list row view
                            .onTapGesture {
                               
                                selectedContact = contact.contact
                                isLogin = true
                            }
                            .swipeActions(edge: .trailing) { // Swipe to delete contact
                                Button(role: .destructive) {
                                    
                                    deletedContact = contact.contact
                                    contactViewModel.activeAlert = .delete
                                    contactViewModel.isOpenAlert = true
                                    
                                } label: {
                                    
                                    Text("Delete")
                                }
                            }
                    }
                }
                .listStyle(.insetGrouped)
                .onAppear() {
                    // Ask for contact access permission and fetch contacts on appearing list
                    contactViewModel.requestAccess()
                }
                .toolbar {
                    // MARK: - Add Button
                    
                    ToolbarItem(placement: .topBarTrailing, content: {
                        // Add button
                        Button {
                            
                            isLogin = true
                            
                        } label: {
                            
                            Label("Add Item", systemImage: "plus")
                        }
                        
                    })
                }
            }
            // MARK: - Contact/Delete Access Alert
            
            .alert(isPresented: $contactViewModel.isOpenAlert, content: {
                // Alert for contact access and delete confirmation
                switch contactViewModel.activeAlert {
                case .delete:
                    
                    Alert(title: Text("Delete"), message: Text("Are you sure you want to delete this contact permanently?"), primaryButton: .destructive(Text("Delete"), action: {
                        
                        withAnimation {
                            
                            if let index = contactViewModel.contacts.firstIndex(where: {$0.contact.identifier == deletedContact.identifier}){
                                
                                let contact = contactViewModel.contacts[index]
                                contactViewModel.contacts.remove(at: index)
                                
                                let req = CNSaveRequest()
                                let mutableContact = contact.contact.mutableCopy() as! CNMutableContact
                                req.delete(mutableContact)
                                
                                do{
                                    try store.execute(req)
                                    
                                    print("Successfully deleted the user")
                                } catch let e{
                                    print("Error = \(e)")
                                }
                            }
                            
                            deletedContact = CNContact()
                        }
                        
                    }), secondaryButton: .cancel(Text("Cancel"), action: {
                        
                        deletedContact = CNContact()
                    }))
                    
                case .contact_accesss:
                    
                    Alert(title: Text("Alert"), message: Text("Need contact access permission"), primaryButton: .default(Text("Go to Setting"), action: {
                        
                        UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
                        
                    }), secondaryButton: .cancel(Text("Cancel"), action: {
                        
                        contactViewModel.isOpenAlert = false
                    }))
                }
            })
            .fullScreenCover(isPresented: $isLogin, content: {
                // Full-screen cover for contact UI screen
                createContactViewController()
                    .onDisappear(perform: {
                        
                        selectedContact = CNContact()
                        favoritesViewModel.getFav()
                        contactViewModel.requestAccess()
                    })
                    .tint(Color.AppTheme.appPrimary)
                    .navigationBarHidden(true)
                    .navigationBarBackButtonHidden(true)
            })
            .onAppear(perform: {
                // Actions on view appear
                selectedContact = CNContact()
                favoritesViewModel.getFav()
            })
            .navigationBarTitle("Contacts",displayMode: .inline)
        }
    }
   
    // MARK: - Helper Functions
    
    /**
     Creates a MyCNContactViewController instance.
     
     - Returns: An instance of MyCNContactViewController.
     */
    func createContactViewController() -> MyCNContactViewController {
        let vc = MyCNContactViewController(contact: $selectedContact)
        return vc
    }
}

