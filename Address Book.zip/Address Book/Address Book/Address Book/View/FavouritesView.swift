//**********************************************************************************************
//
//  FavouritesView.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI
import CoreData
import Contacts
import ContactsUI

/**
 View for displaying favorite contacts.
 */
struct FavouritesView: View {
    
    @State private var searchText = ""
    @State private var showCancelButton: Bool = false
    @State var isLogin = false
    @StateObject var favViewModel = FavouritesViewModel()
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                
                if !favViewModel.arrContacts.isEmpty {
                    
                    List {
                        
                        ForEach(favViewModel.arrContacts) { contact in
                            
                            ContactCellView(contact: contact, favViewModel: favViewModel)
                        }
                    }
                    .listStyle(.insetGrouped)
                }
                else
                {
                    VStack {
                        
                        Spacer()
                        
                        Text("You haven't set any favourite yet.")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundStyle(Color(.lightGray))
                        
                        Spacer()
                    }
                }
            }
            .onAppear {
                
                favViewModel.getFav()
                favViewModel.getContacts()
            }
            .navigationBarTitle("Favourites", displayMode: .inline)
        }
    }
}



