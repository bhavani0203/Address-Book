//**********************************************************************************************
//
//  GroupListView.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************


import SwiftUI
import CoreData

/**
 View for displaying and managing groups.
 */
struct GroupListView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Group.groupID, ascending: true)],
        animation: .default)
    
    private var items: FetchedResults<Group>
    
    @State private var searchText = ""
    @State private var showCancelButton: Bool = false
    
    @State var showsAlert = false
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                
                //MARK: - Search Bar
                
                HStack {
                    
                    HStack {
                        
                        // Search bar magnifying glass image
                        Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                        
                        // Search bar text field
                        TextField("Search", text: self.$searchText, onEditingChanged: { isEditing in
                            self.showCancelButton = true
                        })
                        
                        // X Button
                        Button(action: {
                            self.searchText = ""
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                                .opacity(self.searchText == "" ? 0 : 1)
                        }
                    }
                    .padding(8)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(8)
                    
                    // Cancel Button
                    if self.showCancelButton  {
                        Button("Cancel") {
                            UIApplication.shared.endEditing(true)
                            self.searchText = ""
                            self.showCancelButton = false
                        }
                    }
                }
                .padding([.leading, .trailing])
                .padding(.top, 10)
                
                //MARK: - Group List
                
                VStack {
                    
                    let arrContact = self.items.filter({ (cont) -> Bool in
                        
                        self.searchText.isEmpty ? true :
                        "\(cont.name ?? "")".lowercased().contains(self.searchText.lowercased())
                        
                    })
                    
                    if !arrContact.isEmpty {
                        
                        List { // Group list
                            
                            ForEach(arrContact) { contact in
                                
                                NavigationLink {
                                    
                                    GroupContactList(group: contact)
                                        .navigationBarTitle(contact.name ?? "")
                                    
                                } label: {
                                    
                                    Text(contact.name ?? "")
                                }
                            }
                            .onDelete(perform: deleteItems) // Swipe to delete
                        }
                        .listStyle(.insetGrouped)
                    }
                    else
                    {
                        VStack {
                            
                            Spacer()
                            
                            Text("You haven't created any group yet.")
                                .font(.system(size: 20, weight: .medium))
                                .foregroundStyle(Color(.lightGray))
                            
                            Spacer()
                        }
                    }
                }
                .toolbar { // Top bar actions: add group or edit group
                   
                    ToolbarItem {
                        
                        Button { // Group creation alert
                            
                            createAlert(alertController: UIAlertController(title: "Group name", message: "", preferredStyle: .alert), placeholder: "Group name") { name in
                                
                                if name != "" {
                                    
                                    if items.firstIndex(where: {$0.name == name}) == nil{
                                        
                                        addItem(name: name)
                                    }
                                    else
                                    {
                                        showsAlert = true
                                    }
                                }
                            }
                            
                        } label: {
                            
                            Label("Add Group", systemImage: "plus")
                            
                        }
                        .alert(isPresented: self.$showsAlert) {
                            
                            Alert(title: Text("Group exists"))
                        }
                    }
                }
            }
            .navigationBarTitle("Groups", displayMode: .inline)
        }
    }
    
    /**
     Deletes selected items from the group.
     
     - Parameter offsets: Index set of items to delete.
     */
    private func deleteItems(offsets: IndexSet) {
        
        withAnimation {
            
            let index = offsets[offsets.startIndex]
            let group = items[index]
            viewContext.delete(group)
            
            do{
                try viewContext.save()
                print("Successfully deleted group")
            } catch let e{
                print("Error = \(e)")
            }
        }
    }
    
    /**
     Creates an alert for creating a new group.
     
     - Parameters:
        - alertController: UIAlertController for group creation.
        - placeholder: Placeholder text for group name.
        - saveAction: Closure to save group name.
     */
    func createAlert(alertController: UIAlertController, placeholder: String, saveAction: @escaping (String) -> Void) {
        
        let alert = alertController
        
        alert.addTextField { textField in
            
            textField.placeholder = placeholder
        }
        
        let saveButton = UIAlertAction(title: "Save", style: .default) { _ in
            
            guard let text = alert.textFields?[0].text else { return }
            saveAction(text)
            
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .default)
        alert.addAction(saveButton)
        alert.addAction(cancel)
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let rootViewController = windowScene.windows.first?.rootViewController {
            rootViewController.present(alert, animated: true)
        }

    }
    
    /**
     Adds a new group to CoreData.
     
     - Parameter name: Name of the new group.
     */
    private func addItem(name: String) {
        
        withAnimation {
            
            let newItem = Group(context: viewContext)
            newItem.groupID = UUID().uuidString
            newItem.name = name
            
            do {
                try viewContext.save()
            } catch {
                
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

struct GroupListView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        GroupListView()
    }
}

