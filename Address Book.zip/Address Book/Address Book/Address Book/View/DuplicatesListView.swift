//**********************************************************************************************
//
//  DupliactesListView.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import SwiftUI

/**
 View for displaying duplicate contacts.
 */
struct DuplicatesListView: View {
    
    @StateObject var favViewModel = FavouritesViewModel()
    @StateObject var contactVieWModel = ContactViewModel(pageType: .duplicate)
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                
                if !contactVieWModel.contacts.isEmpty {
                    
                    //MARK: - Contact List
                    
                    List {
                        
                        ForEach(contactVieWModel.contacts) { contact in
                            
                            ContactCellView(contact: contact, favViewModel: favViewModel) //contact list row view
                        }
                    }
                    .listStyle(.insetGrouped)
                }
                else
                {
                    VStack {
                        
                        Spacer()
                        
                        Text("Duplicate contact not found")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundStyle(Color(.lightGray))
                        
                        Spacer()
                    }
                }
            }
            .onAppear(perform: {
            
                contactVieWModel.requestAccess()
            })
            //MARK: - Contact Access Alert
            .alert(isPresented: $contactVieWModel.isOpenAlert, content: {
                
                Alert(title: Text("Alert"), message: Text("Need contact access permission"), primaryButton: .default(Text("Go to Setting"), action: {
                    
                    UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
                    
                }), secondaryButton: .cancel(Text("Cancel"), action: {
                    
                    contactVieWModel.isOpenAlert = false
                }))
            })
            .navigationBarTitle("Duplicate Contacts", displayMode: .inline)
            .toolbar {
                
                ToolbarItem(placement: .topBarTrailing) {
                    
                    if contactVieWModel.contacts.count > 0 {
                        
                        Button("Merge") {
                            
                            DispatchQueue.main.async {
                                
                                contactVieWModel.mergeDuplicateContacts()
                            }
                        }
                    }
                }
                
            }
        }
    }
}



