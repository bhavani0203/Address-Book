//**********************************************************************************************
//
//  NewContact.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import Foundation
import Contacts
import ContactsUI
import SwiftUI

/// Global instance of CNContactStore for managing contacts.
var store = CNContactStore()

/**
 Represents a view controller for managing CNContact details.
 */
struct MyCNContactViewController: UIViewControllerRepresentable {
    
    /// Creates a coordinator instance for managing interactions with the contact view controller.
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    /// The environment variable for dismissing the view.
    @Environment(\.dismiss) var dismiss
    typealias UIViewControllerType = UINavigationController
    
    /// The binding for the CNContact object.
    @Binding var contact : CNContact
    
    /**
     Creates and configures the CNContactViewController.
     
     - Parameter context: The context for the view controller.
     - Returns: A UINavigationController containing the CNContactViewController.
     */
    func makeUIViewController(context: UIViewControllerRepresentableContext<MyCNContactViewController>) -> UINavigationController {
        let vc = CNContactViewController(forNewContact: contact)
        vc.allowsActions = true
        vc.allowsEditing = true
        vc.delegate = context.coordinator
        let navigationController = UINavigationController(rootViewController: vc)
        return navigationController
    }
    
    /**
     Updates the CNContactViewController.
     
     - Parameters:
        - uiViewController: The UINavigationController containing the CNContactViewController.
        - context: The context for the view controller.
     */
    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        print("Update")
    }
    
    /**
     A coordinator class for managing delegate methods of CNContactViewController.
     */
    class Coordinator: NSObject, CNContactViewControllerDelegate {
        
        /// The parent MyCNContactViewController instance.
        var parent: MyCNContactViewController
        
        /// Initializes the coordinator with a parent MyCNContactViewController.
        init(_ parent: MyCNContactViewController) {
            self.parent = parent
        }
        
        /**
         Notifies the delegate that the user canceled the view controller.
         
         - Parameters:
            - viewController: The CNContactViewController object.
            - contact: The CNContact object representing the canceled contact.
         */
        func contactViewController(_ viewController: CNContactViewController, didCompleteWith contact: CNContact?) {
            print("Cancel")
            DispatchQueue.main.async {
                self.parent.dismiss()
            }
        }
        
        /**
         Asks the delegate whether the default action for a contact property should be performed.
         
         - Parameters:
            - viewController: The CNContactViewController object.
            - property: The CNContactProperty object for which the default action is requested.
         - Returns: A Boolean value indicating whether the default action should be performed.
         */
        func contactViewController(_ viewController: CNContactViewController, shouldPerformDefaultActionFor property: CNContactProperty) -> Bool {
            return true
        }
    }
}

