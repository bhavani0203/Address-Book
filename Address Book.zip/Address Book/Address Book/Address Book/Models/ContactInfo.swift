//**********************************************************************************************
//
//  ContactInfo.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import Foundation
import Contacts
import UIKit
import ContactsUI
import CoreData


struct ContactInfo : Identifiable,Hashable{ //for store contact detail structure
    
    var id:String
    var contact = CNContact()
    var firstName: String
    var lastName: String
    var phoneNumber: CNPhoneNumber?
    
}
