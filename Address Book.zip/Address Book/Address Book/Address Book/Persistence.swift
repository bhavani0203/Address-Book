//**********************************************************************************************
//
//  Persistence.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************
import CoreData

/**
 A utility class for managing Core Data persistence.
 */
struct PersistenceController {
    /// Shared instance of PersistenceController for access throughout the app.
    static let shared = PersistenceController()

    /// Preview instance of PersistenceController for use in previews.
    static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let viewContext = result.container.viewContext
        do {
            try viewContext.save()
        } catch {
            // Handle the error appropriately during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
        return result
    }()

    /// The main container for Core Data.
    let container: NSPersistentContainer

    /**
     Initializes the PersistenceController.
     
     - Parameter inMemory: A boolean indicating whether to use in-memory storage (for previews).
     */
    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "Address_Book")
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
    }
}

