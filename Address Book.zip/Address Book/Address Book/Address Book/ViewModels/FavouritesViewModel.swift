//**********************************************************************************************
//
//  FavouritesViewModel.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import Foundation

/**
 View model for managing favorite contacts.
 */
class FavouritesViewModel : ObservableObject {
        @Published var arrFavs = [String]()
        @Published var arrContacts = [ContactInfo]()
    init(){
        arrFavs = defaults.value(forKey: UserDefaultKey.favourites) as? [String] ?? []
    }
    
    /**
     Retrieves favorite contacts from UserDefaults.
     */
    func getFav(){
        arrFavs = defaults.value(forKey: UserDefaultKey.favourites) as? [String] ?? []
    }
    
    /**
     Fetches contacts from the device. This method runs in the background to fetch contacts and update the arrContacts array.
     */
    func getContacts() {
        DispatchQueue.global(qos: .background).async {
            var newArray = [ContactInfo]()
            let allContacts = FetchContacts().fetchingContacts(isGroup: false, Group: [Contacts](), isUnselecte: false)
            
            for obj in self.arrFavs {
                if let data = allContacts.first(where: {$0.contact.identifier == obj}) {
                    newArray.append(data)
                }
                
                if obj == self.arrFavs.last {
                    DispatchQueue.main.async {
                        self.arrContacts = newArray
                    }
                }
            }
        }
    }
    
    /**
     Sets a contact as favorite or unfavorite.
     
     - Parameter contactID: The ID of the contact to be favorited or unfavorited.
     */
    func setFavUnfav(contactID:String){
        if let index = arrFavs.firstIndex(where: {$0 == contactID}) {
            arrFavs.remove(at: index)
            
            if arrContacts.count > 0 , let contactIndex = arrContacts.firstIndex(where: {$0.contact.identifier == contactID}) {
                arrContacts.remove(at: contactIndex)
            }
        }
        else
        {
            arrFavs.append(contactID)
        }
        
        DispatchQueue.main.async {
            defaults.setValue(self.arrFavs, forKey: UserDefaultKey.favourites)
        }
    }
    
    /**
     Checks if a contact is marked as favorite.
     
     - Parameter contactId: The ID of the contact to check.
     - Returns: A boolean indicating whether the contact is favorite.
     */
    func isFav(contactId:String) -> Bool {
        return arrFavs.contains(contactId)
    }
}

