//**********************************************************************************************
//
//  FetchContacts.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import Foundation
import Contacts
import UIKit
import ContactsUI
import CoreData

class FetchContacts {
    
    /**
     Fetches contacts based on specified parameters.
     
     - Parameters:
        - isGroup: A boolean indicating if contacts belong to a group.
        - Group: An array of Contacts representing the group.
        - isUnselecte: A boolean indicating if contacts are unselected.
     - Returns: An array of ContactInfo objects.
     */
    func fetchingContacts(isGroup:Bool,Group:[Contacts],isUnselecte:Bool) -> [ContactInfo] {
        
        var contacts = [ContactInfo]()
        
        let keys =  [CNContactViewController.descriptorForRequiredKeys()] as [CNKeyDescriptor]
        let request = CNContactFetchRequest(keysToFetch: keys as [CNKeyDescriptor])
       
        do {
            try store.enumerateContacts(with: request, usingBlock: { (contact, stopPointer) in
                
                if isGroup {
                    //List of contacts added to group
                    if isUnselecte {
                        
                        if Group.first(where: {$0.contactId == contact.identifier}) == nil{
                            contacts.append(ContactInfo(id: contact.identifier, contact: contact, firstName: contact.givenName, lastName: contact.familyName, phoneNumber: contact.phoneNumbers.first?.value))
                        }
                        
                    }else{
                        //List of contacts not added to group

                        if Group.first(where: {$0.contactId == contact.identifier}) != nil{
                            contacts.append(ContactInfo(id: contact.identifier, contact: contact, firstName: contact.givenName, lastName: contact.familyName, phoneNumber: contact.phoneNumbers.first?.value))
                        }
                        
                    }
                    
                }else{
                    //get all the contacts 

                    contacts.append(ContactInfo(id: contact.identifier, contact: contact, firstName: contact.givenName, lastName: contact.familyName, phoneNumber: contact.phoneNumbers.first?.value))
                    
                }
            })
            
        } catch let error {
            
            print("Failed", error)
            
        }
        
        contacts = contacts.sorted {
            
            $0.firstName < $1.firstName
            
        }
        return contacts
    }
}

