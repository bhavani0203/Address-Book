//**********************************************************************************************
//
//  ContactViewModel.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import Foundation
import Contacts
import UIKit
import ContactsUI
import SwiftUI

/// Enum representing different pages in the contact view model.
enum Page {
    case duplicate
    case contact
    case group_contact
}

/**
 View model for managing contacts and contact access.
 */
class ContactViewModel : ObservableObject {
    
    @Published var isOpenAlert = false
    @Published var activeAlert : ActiveAlert = .contact_accesss
    @Published var contacts = [ContactInfo]()
    @Published var pageType : Page = .duplicate
    
    /**
     Initializes the ContactViewModel.
     
     - Parameter pageType: The type of page to initialize.
     */
    init(pageType: Page) {
        self.pageType = pageType
    }
    
    /**
     Requests access to contacts and fetches contacts based on the authorization status.
     */
    func requestAccess() {
        switch CNContactStore.authorizationStatus(for: .contacts) {
        case .authorized:
            self.getContacts()
        case .denied, .restricted, .notDetermined:
            self.goForAccessContacts()
        @unknown default:
            print("error")
        }
    }
    
    /**
     Handles contact access request and fetches contacts if access is granted.
     */
    func goForAccessContacts() {
        store.requestAccess(for: .contacts) { granted, error in
            DispatchQueue.main.async {
                if granted {
                    self.getContacts()
                }
                else {
                    self.activeAlert = .contact_accesss
                    self.isOpenAlert = true
                }
            }
        }
    }
    
    /**
     Fetches contacts based on the page type.
     */
    func getContacts() {
        switch self.pageType {
        case .duplicate:
            DispatchQueue.global(qos: .background).async {
                var arrContacts = [ContactInfo]()
                let dupcontacts = self.getDuplicateContacts()
                print("dupcontacts:",dupcontacts)
                
                if dupcontacts.count > 0 {
                    for contact in dupcontacts {
                        arrContacts.append(ContactInfo(id: contact.identifier, contact: contact, firstName: contact.givenName, lastName: contact.familyName, phoneNumber: contact.phoneNumbers.first?.value))
                        if contact == dupcontacts.last {
                            DispatchQueue.main.async {
                                self.contacts = arrContacts
                            }
                        }
                    }
                }
                else {
                    DispatchQueue.main.async {
                        self.contacts.removeAll()
                    }
                }
            }
        case .contact :
            DispatchQueue.global(qos: .background).async {
                self.contacts = FetchContacts().fetchingContacts(isGroup: false, Group: [Contacts](), isUnselecte: false)
            }
        default :
            DispatchQueue.global(qos: .background).async {
                self.contacts = FetchContacts().fetchingContacts(isGroup: false, Group: [Contacts](), isUnselecte: false)
            }
        }
    }
    
    /**
     Filters contacts based on a search query.
     
     - Parameter query: The search query to filter contacts.
     - Returns: An array of filtered ContactInfo objects.
     */
    func filteredContact(_ query: String) -> [ContactInfo] {
        let lowercasedQuery = query.lowercased()
        return contacts.filter { $0.firstName.lowercased().contains(lowercasedQuery) || $0.lastName.lowercased().contains(lowercasedQuery)}
    }
    
    /**
     Retrieves duplicate contacts from the contact store.
     
     - Returns: An array of duplicate CNContact objects.
     */
    func getDuplicateContacts() -> [CNContact] {
        var duplicates: [CNContact] = []
        var contactsByIdentifier: [String: [CNContact]] = [:]

        // Fetch all contacts
        let keysToFetch =  [CNContactViewController.descriptorForRequiredKeys()] as [CNKeyDescriptor]
        let fetchRequest = CNContactFetchRequest(keysToFetch: keysToFetch)

        try? store.enumerateContacts(with: fetchRequest) { contact, _ in
            if contact.phoneNumbers.count > 0, let identifier = contact.phoneNumbers.first?.value.stringValue {
                if var contacts = contactsByIdentifier[identifier] {
                    contacts.append(contact)
                    contactsByIdentifier[identifier] = contacts
                } else {
                    contactsByIdentifier[identifier] = [contact]
                }
            }
        }

        for (_, contacts) in contactsByIdentifier {
            if contacts.count > 1 {
                duplicates.append(contentsOf: contacts)
            }
        }

        return duplicates
    }
    
    /**
     Merges duplicate contacts in the contact store.
     */
    func mergeDuplicateContacts() {
        var contactsByIdentifier: [String: [CNContact]] = [:]

        // Fetch all contacts
        let keysToFetch =  [CNContactViewController.descriptorForRequiredKeys()] as [CNKeyDescriptor]
        let fetchRequest = CNContactFetchRequest(keysToFetch: keysToFetch)

        try? store.enumerateContacts(with: fetchRequest) { contact, _ in
            if contact.phoneNumbers.count > 0, let identifier = contact.phoneNumbers.first?.value.stringValue {
                if var contacts = contactsByIdentifier[identifier] {
                    contacts.append(contact)
                    contactsByIdentifier[identifier] = contacts
                }
                else
                {
                    contactsByIdentifier[identifier] = [contact]
                }
            }
        }
        
        print("contactsByIdentifier:",contactsByIdentifier)

        for (_, contacts) in contactsByIdentifier {
            if contacts.count > 1 {
                // Merge or delete duplicates
                for index in 0..<contacts.count {
                    let duplicateContact = contacts[index]
                    let req = CNSaveRequest()
                    let mutableContact = duplicateContact.mutableCopy() as! CNMutableContact
                    req.delete(mutableContact)
                    
                    if index == contacts.count - 1{
                        do{
                            try store.execute(req)
                            print("Successfully merged")
                            getContacts()
                        } catch let e
                        {
                            print("Error = \(e)")
                        }
                    }
                }
            }
        }
    }
    
}
