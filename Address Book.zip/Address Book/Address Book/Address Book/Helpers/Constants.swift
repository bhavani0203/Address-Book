//**********************************************************************************************
//
//  Constants.swift
//  Address Book
//  CSCI 521 Project
//
//  Created by Prem Sai Tupalle (z1968860) and Venkata Lakshmi Bhavani Timididhapati (Z1968321)
//
//**********************************************************************************************

import Foundation
import UIKit
import SwiftUI

// UserDefaults instance for storing application data
let defaults = UserDefaults.standard

// Key constants for UserDefaults
struct UserDefaultKey {
    static let favourites = "favourites"
}

// Extension to UIColor for defining application color theme
extension UIColor {
    enum AppTheme {
        static let appPrimary = UIColor(named: "appPrimary")!
    }
}

// Extension to Color for defining application color theme in SwiftUI
extension Color {
    enum AppTheme {
        static let appPrimary = Color("appPrimary")
    }
}

// Extension to UIApplication for hiding the keyboard
extension UIApplication {
    func endEditing(_ force: Bool) {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

